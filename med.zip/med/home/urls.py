from home import views
from django.contrib import admin
from django.urls import path
from home.views import custom_404_view

urlpatterns = [
    path('login', views.login, name = "login"),
    path('forgot_pass', views.forgot_pass, name = 'forgot_pass'),
    path('about_us', views.about_us, name = "about_us"),
    path('medicine_list', views.medicine_list, name='medicine_list'),
    path('catalog', views.catalog, name = 'catalog'),
    path('search', views.search, name = "search"),
    # path('cart', views.cart, name = 'cart'),
    path('contact_us', views.contact_us, name = 'contact_us'),
    path('medicine_detail', views.medicine_detail, name = 'medicine_detail'),
    path('order_history', views.order_history, name = 'order_history'),
    path('order_confirmation', views.order_confirmation, name = 'order_confirmation'),
    path('privacy_policy', views.catalog, name = 'catalog'),
    path('profile', views.profile, name = 'profile'),
    path('register', views.register, name = 'register'),
    path('terms_and_conditions', views.terms_and_conditions, name = 'terms_and_conditions'),
    
    # Home page
    path('', views.home, name='home'),
    
    # Product Page 
    path('products/', views.product_list_view, name = 'product_list'),
    path('products/<pid>/', views.product_detail_view, name = 'product_detail'),
    
    # category Page
    path('category/', views.category_list_view, name = 'category_list'),
    path('category/<cid>/', views.category_product_list_view, name = 'category_product_list'),
    
    # Vendor Page
    path('vendor/', views.vendor_list_view, name = 'vendor_list'),
    path('vendor/<vid>/', views.vendor_detail_view, name = 'vendor_detail'),
    
    # Tags
    path('products/tag/<tag_slug>/', views.tag_list, name = 'tags'),
    
    # Reviews
    path('ajax-add-review/<int:pid>', views.ajax_add_review, name = 'ajax-add-review'),
    
    # Search
    path('search/', views.search_view, name = 'search'),
    
    path('filter-products/', views.filter_product, name = 'filter-product'),
    

    # path('products/<str:product_id>/edit-review/', views.edit_review, name='edit_review'),

    # add to cart
    path('add-to-cart/', views.add_to_cart, name = 'add-to-cart'),
    
    # cart page 
    path('cart/', views.cart_view, name = 'cart'),
    
    # delete from cart
    path('delete-from-cart/', views.delete_item_from_cart, name = 'delete-from-cart'),
    
    # update cart
    path('update-cart/', views.update_cart, name = 'update-cart'),
    
    # check out 
    path('checkout/', views.checkout_view, name = 'checkout'),
    
]   

handler404 = custom_404_view