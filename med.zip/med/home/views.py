from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from home.models import Product, Category, Vendor, CartOrderItems, CartOrder, ProductImages,ProductReview,Wishlist, Address
from django.db.models import Count, Avg
from taggit.models import Tag
from django.template.loader import render_to_string

from home.forms import ProductReviewForm
import json
from django.contrib import messages


# Create your views here.

def custom_404_view(request, exception):
    return render(request, '404.html', status=404)

from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse
from django.db.models import Avg, Count
import json

def home(request):
    product = Product.objects.filter(product_status="published", featured=True).order_by("-id")
    context = {
        "products": product
    }
    return render(request, 'home.html', context)

def product_list_view(request):
    products = Product.objects.filter(product_status="published").order_by("-date")
    categories = Category.objects.all()
    vendors = Vendor.objects.all()
    tags = Tag.objects.all()
    price_range = list(range(100, 1100, 100))
    context = {
        "products": products,
        'categories': categories,
        'vendors': vendors,
        'tags': tags,
        'price_range': json.dumps(price_range)
    }
    return render(request, 'product_list.html', context)

def product_detail_view(request, pid):
    product = get_object_or_404(Product, pid=pid)
    products = Product.objects.filter(category=product.category)
    reviews = ProductReview.objects.filter(product=product).order_by("-date")
    average_rating = ProductReview.objects.filter(product=product).aggregate(rating=Avg('rating'))
    p_image = product.product_images.all()
    
    # Product Review Form
    review_form = ProductReviewForm()
    make_review = True

    if request.user.is_authenticated:
        user_review_count = ProductReview.objects.filter(user=request.user, product=product).count()
        if user_review_count > 0:
            make_review = False

    context = {
        "review_form": review_form,
        "make_review": make_review,
        "product": product,
        "p_image": p_image,
        "products": products,
        "reviews": reviews,
        "average_rating": average_rating,
    }
    return render(request, "product_detail.html", context)

def category_list_view(request):
    categories = Category.objects.all()
    context = {
        "categories": categories
    }
    return render(request, "category_list.html", context)

def category_product_list_view(request, cid):
    category = get_object_or_404(Category, cid=cid)
    products = Product.objects.filter(product_status="published", category=category)
    context = {
        "category": category,
        "products": products,
    }
    return render(request, "category_product_list.html", context)

def vendor_list_view(request):
    vendors = Vendor.objects.all()
    context = {
        'vendors': vendors,
    }
    return render(request, "vendor_list.html", context)

def vendor_detail_view(request, vid):
    vendor = get_object_or_404(Vendor, vid=vid)
    products = Product.objects.filter(vendor=vendor, product_status="published")
    context = {
        'vendor': vendor,
        'products': products,
    }
    return render(request, "vendor_detail.html", context)

def tag_list(request, tag_slug=None):
    products = Product.objects.filter(product_status="published").order_by("-id")
    tag = None
    if tag_slug:
        tag = get_object_or_404(Tag, slug=tag_slug)
        products = products.filter(tags__in=[tag])
    context = {
        "products": products,
        "tag": tag,
    }
    return render(request, "tag.html", context)

def ajax_add_review(request, pid):
    try:
        product = get_object_or_404(Product, pk=pid)
        user = request.user
        review_text = request.POST.get('review')
        rating = request.POST.get('rating')

        if not review_text or not rating:
            return JsonResponse({'success': False, 'message': 'Review and rating are required.'}, status=400)

        review = ProductReview.objects.create(
            user=user,
            product=product,
            review=review_text,
            rating=rating,
        )
        
        average_rating = ProductReview.objects.filter(product=product).aggregate(avg_rating=Avg("rating"))['avg_rating']
        
        context = {
            'user': user.username,
            'review': review_text,
            'rating': rating,
            'average_rating': average_rating,
        }
        return JsonResponse({'success': True, 'context': context})
    except Product.DoesNotExist:
        return JsonResponse({'success': False, 'message': 'Product not found.'}, status=404)
    except Exception as e:
        return JsonResponse({'success': False, 'message': str(e)}, status=500)

def search_view(request):
    query = request.GET.get("q")
    products = Product.objects.filter(title__icontains=query).order_by("-date")
    context = {
        "products": products,
        "query": query,
    }
    return render(request, "search.html", context)

def filter_product(request):
    categories = request.GET.getlist("category[]")
    vendors = request.GET.getlist("vendor[]")
    tags = request.GET.getlist("tag[]")
    min_price = request.GET.get('min_price')
    max_price = request.GET.get('max_price')
    
    products = Product.objects.filter(product_status="published", price__gte=min_price, price__lte=max_price)

    if categories:
        products = products.filter(category__id__in=categories)
        
    if vendors:
        products = products.filter(vendor__id__in=vendors)

    if tags:
        products = products.filter(tag__id__in=tags).distinct()

    data = render_to_string("async/product-list.html", {"products": products})
    return JsonResponse({"data": data})

def add_to_cart(request):
    try:
        id = request.GET.get('id')
        if id:
            cart_product = {
                str(id): {
                    'title': request.GET.get('title', ''),
                    'qty': request.GET.get('qty', ''),
                    'price': request.GET.get('price', ''),
                    'image': request.GET.get('image', ''),
                    'pid': request.GET.get('pid', ''),
                }
            }

            if 'cart_data_obj' in request.session:
                cart_data = request.session['cart_data_obj']
                if str(id) in cart_data:
                    cart_data[str(id)]['qty'] = int(cart_product[str(id)]['qty'])
                else:
                    cart_data.update(cart_product)
                request.session['cart_data_obj'] = cart_data
            else:
                request.session['cart_data_obj'] = cart_product
                
            return JsonResponse({"data": request.session['cart_data_obj'], 'totalcartitem': len(request.session['cart_data_obj'])})
        else:
            return JsonResponse({"error": "Missing 'id' parameter in the request."}, status=400)
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)
    
# def cart_view(request):
#     cart_total_amount = 0
#     if 'cart_data_obj' in request.session:
#         for product_id, item in request.session['cart_data_obj'].items():
#             try:
#                 quantity = int(item['qty'])
#                 price = float(item['price'])
#                 cart_total_amount += quantity * price
#             except ValueError as e:
#                 print(f"Error processing item {product_id}: {e}")
#         return render(request, "cart.html", {"cart_data": request.session['cart_data_obj'], 'totalcartitem': len(request.session['cart_data_obj']), 'cart_total_amount': cart_total_amount})
#     else:
#         messages.warning(request, "Your cart is empty")
#         return redirect("home")

    
def cart_view(request):
    cart_total_amount = 0
    if 'cart_data_obj' in request.session:
        for product_id, item in request.session['cart_data_obj'].items():
            cart_total_amount += int(item['qty']) * float(item['price'])
        return render(request, "cart.html",{"cart_data": request.session['cart_data_obj'], 'totalcartitem': len(request.session['cart_data_obj']), 'cart_total_amount': cart_total_amount} )
    else:
        # return render(request, "cart.html",{"cart_data": '', 'totalcartitem': len(request.session['cart_data_obj']), 'cart_total_amount': cart_total_amount} )
        messages.warning(request, "Your cart is empty")
        return redirect("home")
    
# def cart_view(request):
#     cart_total_amount = 0
#     subtotal = 0
#     shipping_charges = 10  # Example fixed shipping charge
#     discount = 5 
    
#     cart_data = request.session.get('cart_data_obj', {})
#     if cart_data:
#         for product_id, item in cart_data.items():
#             try:
#                 # Ensure qty is a valid integer, defaulting to 1 if invalid or empty
#                 qty = int(item.get('qty', 1) or 1)
#                 # Ensure price is a valid float, defaulting to 0.0 if invalid or empty
#                 price = float(item.get('price', 0.0))
#                 item_total = qty * price
#                 item['total'] = item_total  # Store the total for each item
#                 subtotal += item_total
#                 cart_total_amount += item_total
#             except ValueError:
#                 item['total'] = 0  # Handle error and set total to 0 if needed

#         total = subtotal + shipping_charges - discount

#         return render(request, "cart.html", {
#             'cart_data': cart_data,
#             'totalcartitem': len(cart_data),
#             'cart_total_amount': cart_total_amount,
#             'subtotal': subtotal,
#             'shipping_charges': shipping_charges,
#             'discount': discount,
#             'total': total
#         })
#     else:
#         messages.warning(request, "Your cart is empty")
#         return redirect("home")

def delete_item_from_cart(request):
    product_id = str(request.GET['id'])
    if 'cart_data_obj' in request.session:
        if product_id in request.session['cart_data_obj']:
            cart_data = request.session['cart_data_obj']
            del request.session['cart_data_obj'][product_id]
            request.session['cart_data_obj'] = cart_data
        
    cart_total_amount = 0
    if 'cart_data_obj' in request.session:
        for product_id, item in request.session['cart_data_obj'].items():
            cart_total_amount += int(item['qty'])* float(item['price'])    
        
    context = render_to_string("async/cart-list.html", {"cart_data": request.session['cart_data_obj'], 'totalcartitem': len(request.session['cart_data_obj']), 'cart_total_amount': cart_total_amount})
    return JsonResponse({"data": context,  'totalcartitem': len(request.session['cart_data_obj'])})

def update_cart(request):
    product_id = str(request.GET['id'])
    product_qty = request.GET['qty']
    if 'cart_data_obj' in request.session:
        if product_id in request.session['cart_data_obj']:
            cart_data = request.session['cart_data_obj']
            cart_data[str(request.GET['id'])]['qty'] = product_qty
            request.session['cart_data_obj'] = cart_data
        
    cart_total_amount = 0
    if 'cart_data_obj' in request.session:
        for product_id, item in request.session['cart_data_obj'].items():
            cart_total_amount += int(item['qty'])* float(item['price'])    
        
    context = render_to_string("async/cart-list.html", {"cart_data": request.session['cart_data_obj'], 'totalcartitem': len(request.session['cart_data_obj']), 'cart_total_amount': cart_total_amount})
    return JsonResponse({"data": context,  'totalcartitem': len(request.session['cart_data_obj'])})

def checkout_view(request):
    cart_total_amount = 0
    if 'cart_data_obj' in request.session:
        for product_id, item in request.session['cart_data_obj'].items():
            cart_total_amount += int(item['qty'])* float(item['price'])    
        return render(request, "checkout.html",{"cart_data": request.session['cart_data_obj'], 'totalcartitem': len(request.session['cart_data_obj']), 'cart_total_amount': cart_total_amount} )

    



def index(request):
    return render(request, 'index.html')

def login(request):
    return render(request, 'login.html')

def forgot_pass(request):
    return render(request, 'forgot_pass.html')

def about_us(request):
    return render(request, 'about_us.html')

def catalog(request):
    return render(request, 'catalog.html')

def medicine_list(request):
    return render(request, 'medicine_list.html')

def search(request):
    return render(request, 'search.html')

def cart(request):
    return render(request, 'cart.html')



def contact_us(request):
    return render(request, 'contact_us.html')

def medicine_detail(request):
    return render(request, 'medicine_detail.html')

def order_history(request):
    return render(request, 'order_history.html')

def order_confirmation(request):
    return render(request, 'order_confirmation.html')

def privacy_policy(request):
    return render(request, 'privacy_policy.html')

def profile(request):
    return render(request, 'profile.html')

def register(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')

        if password != confirm_password:
            messages.error(request, 'Passwords do not match.')
        elif User.objects.filter(username=username).exists():
            messages.error(request, 'Username is already taken.')
        else:
            User.objects.create_user(username=username, email=email, password=password)
            messages.success(request, 'Account created successfully. Please login.')
            return redirect('login')  # Redirect to login page after successful registration

    return render(request, 'register.html')

def terms_and_conditions(request):
    return render(request, 'terms_and_conditions.html')