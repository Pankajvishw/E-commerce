console.log("working fine");

const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

$("#commentForm").submit(function(e){
    e.preventDefault();

    let dt = new Date();
    let time = dt.getDay() + " " + monthNames[dt.getUTCMonth()] + ", " + dt.getFullYear();



    $.ajax({
        data: $(this).serialize(),

        method: $(this).attr("method"),

        url: $(this).attr("action"),

        dataType: "json",

        success: function(response){
            console.log("Comment saved to DB...");

            if (response.success === true) {
                $("#review-response").html("Review Added Successfully.");
                $(".hide-comment-form").hide()
                $(".add-review").hide()

                let _html = '<div class="d-flex border rounded p-2 mb-2">'
                    _html += '<img src="https://t4.ftcdn.net/jpg/00/64/67/27/360_F_64672736_U5kpdGs9keUll8CRQ3p3YaEv2M6qkVY5.jpg" alt="" class="rounded-circle avatar-lg" style="width: 65px; height: 65px;" />'
                    _html += '<div class="ms-5">'
                    _html += '<h6 class="mb-1">'+ response.context.user +'</h6>'
                    _html += '<p class="small">'
                    _html += '<span class="text-muted">'+ time +'</span>'
                    _html += '<span class="text-primary ms-3 fw-bold">Verified Purchase</span>'
                    _html += '</p>'


                    for(let i = 1; i<= response.context.rating; i++){
                        _html += '<i class="bi bi-star-fill text-warning"></i>'
                    }
                    
                    _html += '<p>'+ response.context.review +'</p>'
                    
                    _html += '</div>'
                    _html += '</div>'

                    $(".comment-list").prepend(_html)

            } else {
                $("#review-response").html("Failed to add review: " + response.message);
            }
            
        }
    })
})


$(document).ready(function(){
    $(".filter-checkbox").on("click", function(){
        console.log("A checkbox have been clicked")

        let filter_object = {}

        $(".filter-checkbox").each(function(){
            let filter_value = $(this).val()
            let filter_key = $(this).data("filter")

            // console.log("filter value is:", filter_value);
            // console.log("filter key is:", filter_key);

            filter_object[filter_key] = Array.from(document.querySelectorAll('input[data-filter=' + filter_key + ']:checked')).map(function(element){
                return element.value
            })
        })
        console.log("Filter object is:", filter_object);
        $.ajax({
            url: '/filter-products',
            data: filter_object,
            dataType: 'json',
            beforeSend: function(){
                console.log("Trying to filter products...");
            },
             success: function(response){
                console.log("Response from server:", response);
                if (response.data) {
                    console.log("Data filtered successfully");
                    $("#filtered-product").html(response.data);
                } else {
                    console.log("No data returned");
                    $("#filtered-product").html("<p>No products found.</p>");
                }
            },
            error: function(xhr, status, error){
                console.error("AJAX error:", status, error);
                $("#filtered-product").html("<p>An error occurred. Please try again.</p>");
            }
        });
    });
});


$(document).ready(function(){
    $(".filter-title, #price-filter-btn").on("click", function(){
    

        console.log("A checkbox has been clicked");

        let filter_object = {};

        let min_price = $("max_price").attr("min")
        let max_price = $("max_price").val

        filter_object.min_price = min_price;
        filter_object.max_price = max_price;

        $(".filter-checkbox").each(function(){
            let filter_value = $(this).val();
            let filter_key = $(this).data("filter");

            if (!(filter_key in filter_object)) {
                filter_object[filter_key] = [];
            }

            if ($(this).is(':checked')) {
                filter_object[filter_key].push(filter_value);
            }

            console.log("Filter Value is : ", filter_value);
            console.log("Filter key is : ", filter_key);

            filter_object[filter_key] = Array.from(document.querySelectorAll('input[data-filter=' + filter_key + ']:checked')).map(function(element){
                return element.value
            })
        });

        console.log("Filter object is:", filter_object);

        $.ajax({
            url: '/filter-products',
            data: filter_object,
            dataType: 'json',
            beforeSend: function(){
                console.log("Trying to filter products...");
            },
            success: function(response){
                console.log("Response from server:", response);
                if (response.data) {
                    console.log("Data filtered successfully");
                    $("#filter-product").html(response.data);
                } else {
                    console.log("No data returned");
                    $("#filtered-product").html("<p>No products found.</p>");
                }
            },
            error: function(xhr, status, error){
                console.error("AJAX error:", status, error);
                $("#filtered-product").html("<p>An error occurred. Please try again.</p>");
            }
        });
    });

    $("#max_price").on("blur", function(){
        let min_price = $(this).attr("min");
        let max_price = $(this).attr("max");
        let current_price = $(this).val();

        console.log("Current Price is: ", current_price);
        console.log("Max Price is: ", max_price);
        console.log("Min Price is: ", min_price);

        if(cureent_price < paraseInt(min_price) || current_price > paraseInt(max_price)){
            console.log("Price wrror Occured");

            min_price = Math.round(min_price *100) / 100
            max_price = Math.round(max_price *100) / 100

            console.log("Max Price is:", min_price);
            console.log("Min Price is:", max_price);

            alert("price must between $" <min_price + ' and $' + max_price)
            $(this).val(min_price)
            $('range').val(min_price)

            $(this).focus()

            return false
        }
    })

    $(".add-to-cart-btn").on("click", function(){


        let this_val = $(this)
        let index = this_val.attr("data-index")
        
    
        let quantity =  $("#product-quantity-" + index).val()
        let product_title =  $("#product-title-" + index).val()
        let product_id =  $("#product-id-" + index).val()
        let product_price =  $(".current-product-price-" + index).text()
        let product_pid =  $("#product-pid").val()
        let product_image =  $("#product-image-" + index).val()
    
    
        console.log("Quantity:", quantity);
        console.log("title:", product_title);
        console.log("price:", product_price);
        console.log("ID:", product_id);
        console.log("Pid:", product_pid);
        console.log("Image:", product_image);
        console.log("Index:", index);
        console.log("Current element:", this_val);
    
        $.ajax({
            url: '/add-to-cart',
            data: {
                'id': product_id,
                'qty': quantity,
                'title': product_title,
                'price': product_price,
                'image': product_image,
                'pid': product_pid,
            },
            dataType: 'json',
            beforeSend: function(){
                console.log("Adding product to cart...");
    
            },
            success: function(response){
                this_val.html("✓")
                console.log("Added Product to cart...");
                $(".cart-items.count").text(response.totalcartitems)
            }
    
        })
    })
    
    
    
    
    $(".delete-product").on("click", function(){
    
        let product_id = $(this).attr("data-product")
        let this_val = $(this)
    
        console.log("product ID: ", product_id);

        $.ajax({
            url: "/delete-from-cart",
            data: {
                "id": product_id
            },
            dataType: "json",
            beforeSend: function(){
                this_val.hide()
            },
            success: function(response){
                this_val.show()
                $(".cart-items.count").text(response.totalcartitems)
                $("#cart-list").html(response.data)
            }

        })
        
    })

    $(".update-product").on("click", function(){
    
        let product_id = $(this).attr("data-product")
        let this_val = $(this)
        let product_quantity = $("#product-qty-"+ product_id).val();
    
        console.log("product ID: ", product_id);
        console.log("product qty: ", product_quantity);

        $.ajax({
            url: "/update-cart",
            data: {
                "id": product_id,
                "qty": product_quantity,
            },
            dataType: "json",
            beforeSend: function(){
                this_val.hide()
            },
            success: function(response){
                this_val.show()
                $(".cart-items.count").text(response.totalcartitems)
                $("#cart-list").html(response.data)
            }

        })
        
    })
    
 
});



// $(".add-to-cart-btn").on("click", function(){


//     let this_val = $(this)
//     let index = this_val.attr("data-index")
    

//     let quantity =  $("#product-quantity-" + index).val()
//     let product_title =  $("#product-title-" + index).val()
//     let product_id =  $("#product-id-" + index).val()
//     let product_price =  $(".current-product-price-" + index).text()
//     let product_pid =  $("#product-pid").val()
//     let product_image =  $("#product-image-" + index).val()


//     console.log("Quantity:", quantity);
//     console.log("title:", product_title);
//     console.log("price:", product_price);
//     console.log("ID:", product_id);
//     console.log("Pid:", product_pid);
//     console.log("Image:", product_image);
//     console.log("Index:", index);
//     console.log("Current element:", this_val);

//     $.ajax({
//         url: '/add-to-cart',
//         data: {
//             'id': product_id,
//             'qty': quantity,
//             'title': product_title,
//             'price': product_price,
//             'image': product_image,
//             'pid': product_pid,
//         },
//         dataType: 'json',
//         beforeSend: function(){
//             console.log("Adding product to cart...");

//         },
//         success: function(response){
//             this_val.html("✓")
//             console.log("Added Product to cart...");
//             $(".cart-items.count").text(response.totalcartitems)
//         }

//     })
// })




// $(".delete-product").on("click", function(){

//     let product_id = $(this).attr("datat-product")
//     let this_val = $(this)

//     console.log("product ID: ", product_id);
    
// })

// for reference

// $("#add-to-cart-btn").on("click", function(){
//     let quantity =  $("#product-quantity").val()
//     let product_title =  $("#product-title").val()
//     let product_id =  $("#product-id").val()
//     let product_price =  $("#current-product-price").text()
//     let this_val = $(this)


//     console.log("Quantity:", quantity);
//     console.log("title:", product_title);
//     console.log("price:", product_price);
//     console.log("ID:", product_id);
//     console.log("Current element:", this_val);

//     $.ajax({
//         url: '/add-to-cart',
//         data: {
//             'id': product_id,
//             'qty': quantity,
//             'title': product_title,
//             'price': product_price,
//         },
//         dataType: 'json',
//         beforeSend: function(){
//             console.log("Adding product to cart...");

//         },
//         success: function(response){
//             this_val.html("Item added to cart")
//             console.log("Added Product to cart...");
//             $(".cart-items.count").text(response.totalcartitems)
//         }

//     })
// })


